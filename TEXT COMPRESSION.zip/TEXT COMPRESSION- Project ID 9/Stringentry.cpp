#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;
int main()
{
	ofstream fout;
	ifstream fin;
	char ch[100];
	fout.open("abc.txt");
	gets(ch);
	fout<<ch;
	return 0;
	
}
